import pygame, sys, random

def ball_animation():
    global ball_speed_x, ball_speed_y, player_score, opp_score, score_time
    ball.x += ball_speed_x
    ball.y += ball_speed_y

    # colisions with wall
    if ball.top <= 0 or ball.bottom >= screen_height:
        pygame.mixer.Sound.play(pong_sound)
        ball_speed_y *= -1

    if ball.left <= 0:
        pygame.mixer.Sound.play(score_sound)
        player_score += 1
        score_time = pygame.time.get_ticks()

    if  ball.right >= screen_width:
        pygame.mixer.Sound.play(score_sound)
        opp_score += 1
        score_time = pygame.time.get_ticks()

    # colisions with paddle
    if ball.colliderect(player) and ball_speed_x > 0:
        pygame.mixer.Sound.play(pong_sound)
        if abs(ball.right - player.left) < 10:
            ball_speed_x *= -1
        elif abs(ball.bottom - player.top) < 10 and ball_speed_y > 0:
            ball_speed_y *= -1
        elif abs(ball.top - player.bottom) < 10 and ball_speed_y < 00:
            ball_speed_y *= -1


    if ball.colliderect(opp) and ball_speed_x < 0:
        pygame.mixer.Sound.play(pong_sound)
        if abs(ball.left - opp.right) < 10:
            ball_speed_x *= -1
        elif abs(ball.bottom - opp.top) < 10 and ball_speed_y > 0:
            ball_speed_y *= -1
        elif abs(ball.top - opp.bottom) < 10 and ball_speed_y < 00:
            ball_speed_y *= -1

def player_animation():
    player.y += player_speed
    if player.top <= 0:
        player.top = 0
    if player.bottom >=screen_height:
        player.bottom = screen_height

def opp_ai():
    if opp.top < ball.y:
        opp.top += opp_speed
    if opp.bottom > ball.y:
        opp.bottom -= opp_speed
    if opp.top <= 0:
        opp.top = 0
    if opp.bottom >=screen_height:
        opp.bottom = screen_height

def ball_start():
    global ball_speed_x, ball_speed_y, score_time

    current_time = pygame.time.get_ticks()
    ball.center = (screen_width/2, screen_height/2)

    if current_time - score_time < 700:
        number_three = game_font.render("3",False, light_grey)
        screen.blit(number_three,(screen_width/2 - 10, screen_height/2 + 20))

    if 700 < current_time - score_time < 1400:
        number_two = game_font.render("2",False, light_grey)
        screen.blit(number_two,(screen_width/2 - 10, screen_height/2 + 20))

    if 1400 < current_time - score_time < 2100:
        number_one = game_font.render("1",False, light_grey)
        screen.blit(number_one,(screen_width/2 - 10, screen_height/2 + 20))


    if current_time - score_time < 2100:
        ball_speed_x, ball_speed_y = 0, 0
    else:
        ball_speed_y = 7 * random.choice((1,-1))
        ball_speed_x = 7 * random.choice((1,-1))
        score_time = None


# Game Setup
pygame.mixer.pre_init(44100,-16,2,512)
pygame.init()
clock = pygame.time.Clock()

# Main Window setup
screen_width = 1280
screen_height = 960
screen = pygame.display.set_mode((screen_width,screen_height))
pygame.display.set_caption('OmegaPong2')

# Game Rectangles
ball = pygame.Rect(screen_width/2 - 15, screen_height/2 - 15,30,30)
player = pygame.Rect(screen_width - 20,screen_height/2 - 70, 10, 140)
opp = pygame.Rect(10, screen_height/2 - 70, 10, 140)

bg_color = pygame.Color('grey12')
light_grey = (200,200,200)

# Ball Speed
ball_speed_x = 7 * random.choice((1,-1))
ball_speed_y = 7 * random.choice((1,-1))

# Player Speed
player_speed = 0
opp_seed = 7

# opp Speed
opp_speed = 7

# Text Variables
player_score = 0
opp_score = 0
game_font = pygame.font.Font("freesansbold.ttf", 32)

# Sound
pong_sound = pygame.mixer.Sound("pong.wav")
score_sound = pygame.mixer.Sound("score.wav")

# Score Timer
score_time = True



while True:
    #close the game
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit

    # Paddle Movement
    if event.type == pygame.KEYDOWN:
        if event.key == pygame.K_DOWN:
            player_speed += 3
        if event.key == pygame.K_UP:
            player_speed -= 3
    if event.type == pygame.KEYUP:
        pygame.event.clear()
        if event.key == pygame.K_DOWN:
            player_speed = 0
        if event.key == pygame.K_UP:
            player_speed = 0
    

    ball_animation()
    player_animation()
    opp_ai()


    
    #Visuals
    screen.fill(bg_color)
    pygame.draw.rect(screen,light_grey, player)
    pygame.draw.rect(screen,light_grey, opp)
    pygame.draw.ellipse(screen, light_grey, ball)
    pygame.draw.aaline(screen, light_grey, (screen_width/2,0), (screen_width/2,screen_height))

    if score_time:
        ball_start()


    player_text = game_font.render(f"{player_score}",False,light_grey)
    screen.blit(player_text,(660, 470))

    opp_text = game_font.render(f"{opp_score}",False,light_grey)
    screen.blit(opp_text,(600, 470))

    # Uptating the window
    pygame.display.flip()
    clock.tick(60)
    
    