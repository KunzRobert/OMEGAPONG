import turtle

wn = turtle.Screen()
wn.title("ONEGA PONG")
wn.bgcolor("black")
wn.setup(width=1000, height=600)
wn.tracer(0)

# Score Counter
score_a = 0
score_b = 0

# Paddle A
paddle_a = turtle.Turtle()
paddle_a.speed(0)
paddle_a.shape("square")
paddle_a.color("turquoise")
paddle_a.shapesize(stretch_wid=5, stretch_len=1)
paddle_a.penup()
paddle_a.goto(-400, 0)

# Paddle B
paddle_b = turtle.Turtle()
paddle_b.speed(0)
paddle_b.shape("square")
paddle_b.color("turquoise")
paddle_b.shapesize(stretch_wid=5, stretch_len=1)
paddle_b.penup()
paddle_b.goto(400, 0)

# Ball
hit_ball = turtle.Turtle()
hit_ball.speed(40)
hit_ball.shape("circle")
hit_ball.color("blue")
hit_ball.penup()
hit_ball.goto(0, 0)
hit_ball.dx = 0.5
hit_ball.dy = -0.5

# Score Write
pen =turtle.Turtle()
pen.speed(0)
pen.color("turquoise")
pen.penup()
pen.hideturtle()
pen.goto(0, 260)
pen.write("Player 1:  0 Player 2:  0", align="center", font=("Courier", 24, "normal"))

# Mittellinie
point1 = (0, -300)
point2 = (0, 300)

turtle.penup()
turtle.goto(point1)
turtle.pendown()
turtle.goto(point2)

#turtle.hideturtle()
#turtle.exitonclick()


#movement_Paddles
# W & S
def paddle_a_up():
    y = paddle_a.ycor()
    y += 20
    paddle_a.sety(y)
 
def paddle_a_down():
    y = paddle_a.ycor()
    y -= 20
    paddle_a.sety(y)

# Arrow Key Down & Up
def paddle_b_up():
    y = paddle_b.ycor()
    y += 20
    paddle_b.sety(y)

def paddle_b_down():
    y = paddle_b.ycor()
    y -= 20
    paddle_b.sety(y)

# Keyboard binding
# W & S
wn.listen()
wn.onkeypress(paddle_a_up, "w")
wn.onkeypress(paddle_a_down, "s")

# Arrow Key Up & Down
wn.onkeypress(paddle_b_up, "Up")
wn.onkeypress(paddle_b_down, "Down")

while True:
    wn.update()


    # Move the Ball 
    hit_ball.setx(hit_ball.xcor() + hit_ball.dx)
    hit_ball.sety(hit_ball.ycor() + hit_ball.dy)
    

    # Border Checking
    # top
    if hit_ball.ycor() > 280:
        hit_ball.sety(280)
        hit_ball.dy *= -1
    # bottom
    if hit_ball.ycor() < -280:
        hit_ball.sety(-280)
        hit_ball.dy *= -1
    # right
    if hit_ball.xcor() > 500:
        hit_ball.goto(0, 0)
        hit_ball.dy *= -1
        score_a += 1
        pen.clear()
        pen.write("Player 1:  {} Player 2: {}".format(score_a, score_b), align="center", font=("Courier", 24, "normal"))
    # left
    if hit_ball.xcor() < -500:
        hit_ball.goto(0, 0)
        hit_ball.dy *= -1
        score_b += 1
        pen.clear()
        pen.write("Player 1:  {} Player 2: {}".format(score_a, score_b), align="center", font=("Courier", 24, "normal"))

    
    # Paddle and Ball collisions
    if (hit_ball.xcor() > 360 and hit_ball.xcor() < 750) and (hit_ball.ycor() < paddle_b.ycor() + 40 and hit_ball.ycor() > paddle_b.ycor() -40):
        hit_ball.setx(340)
        hit_ball.dx *= -1 
 
    if (hit_ball.xcor() < -360 and hit_ball.xcor() > -370) and (hit_ball.ycor() < paddle_a.ycor() + 40 and hit_ball.ycor() > paddle_a.ycor() -40):
        hit_ball.setx(-360)
        hit_ball.dx *= -1 
